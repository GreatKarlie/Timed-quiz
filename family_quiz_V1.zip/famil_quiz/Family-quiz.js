const startButton = document.getElementById('start-btn');
const nextButton = document.getElementById('next-btn');
const questionContainer = document.getElementById('question-container');
const questionElement = document.getElementById('question');
const answerButtonsElement = document.getElementById('answer-buttons');
const timerElement = document.getElementById('timer');

let shuffledQuestions, currentQuestionIndex;
let startTime, interval;

const questions = [
    {
        question: 'Athrah broke her arm by-',
        answers: [
            { text: 'Fighting a boy down a flight of stairs', correct: true },
            { text: 'Tackling a bigger girl in a rugby match', correct: false },
            { text: 'Falling out of a guava tree', correct: false },
            { text: 'Stopping a cupboard falling over getting sweets', correct: false }
        ]
    },
    {
        question: 'What was the name of the game small Kauthar invented?',
        answers: [
            { text: 'Neighbours', correct: false },
            { text: 'Score', correct: true },
            { text: 'Bill Gates', correct: false },
            { text: 'Steve Jobs', correct: false }
        ]
    },
    {
        question: '"Die water is soet" is a quote by',
        answers: [
            { text: 'Boeta Chingy', correct: false },
            { text: 'Aunty Zeez', correct: false },
            { text: '', correct: false },
            { text: 'Pacific Ocean', correct: true }
        ]
    },
    {
        question: 'What is the boiling point of water?',
        answers: [
            { text: '90°C', correct: false },
            { text: '100°C', correct: true },
            { text: '110°C', correct: false },
            { text: '120°C', correct: false }
        ]
    },
    {
        question: 'Which planet is known as the Red Planet?',
        answers: [
            { text: 'Earth', correct: false },
            { text: 'Mars', correct: true },
            { text: 'Jupiter', correct: false },
            { text: 'Saturn', correct: false }
        ]
    }
];

startButton.addEventListener('click', startGame);
nextButton.addEventListener('click', () => {
    currentQuestionIndex++;
    setNextQuestion();
});

function startGame() {
    startButton.classList.add('hide');
    shuffledQuestions = questions.sort(() => Math.random() - 0.5);
    currentQuestionIndex = 0;
    questionContainer.classList.remove('hide');
    startTimer();
    setNextQuestion();
}

function setNextQuestion() {
    resetState();
    showQuestion(shuffledQuestions[currentQuestionIndex]);
}

function showQuestion(question) {
    questionElement.innerText = question.question;
    question.answers.forEach(answer => {
        const button = document.createElement('button');
        button.innerText = answer.text;
        button.classList.add('btn');
        if (answer.correct) {
            button.dataset.correct = answer.correct;
        }
        button.addEventListener('click', selectAnswer);
        answerButtonsElement.appendChild(button);
    });
}

function resetState() {
    clearStatusClass(document.body);
    nextButton.classList.add('hide');
    while (answerButtonsElement.firstChild) {
        answerButtonsElement.removeChild(answerButtonsElement.firstChild);
    }
}

function selectAnswer(e) {
    const selectedButton = e.target;
    const correct = selectedButton.dataset.correct;
    setStatusClass(document.body, correct);
    Array.from(answerButtonsElement.children).forEach(button => {
        setStatusClass(button, button.dataset.correct);
    });
    if (shuffledQuestions.length > currentQuestionIndex + 1) {
        nextButton.classList.remove('hide');
    } else {
        startButton.innerText = 'Restart';
        startButton.classList.remove('hide');
        stopTimer();
    }
}

function setStatusClass(element, correct) {
    clearStatusClass(element);
    if (correct) {
        element.classList.add('correct');
    } else {
        element.classList.add('wrong');
    }
}

function clearStatusClass(element) {
    element.classList.remove('correct');
    element.classList.remove('wrong');
}

function startTimer() {
    startTime = Date.now();
    interval = setInterval(() => {
        const elapsedTime = Math.floor((Date.now() - startTime) / 1000);
        timerElement.innerText = `Time: ${elapsedTime}s`;
    }, 1000);
}

function stopTimer() {
    clearInterval(interval);
    const totalTime = Math.floor((Date.now() - startTime) / 1000);
    timerElement.innerText = `Total Time: ${totalTime}s`;
}
